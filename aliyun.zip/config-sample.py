#coding:utf-8

import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

access_id='aliyun_testid'
access_key_secret='aliyun_testkey'

ecs_vpc_id='i-ecsid'
eip_bandwidth=1
